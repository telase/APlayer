//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PluginDemo.rc
//
#define IDD_MAIN                        101
#define IDC_STATIC_FRAME                1001
#define IDC_STATIC_TIME                 1002
#define IDC_STATIC_FPS                  1003
#define IDC_FLIP                        1004
#define IDC_NORMALIZE                   1004
#define IDC_VIDEO                       1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
